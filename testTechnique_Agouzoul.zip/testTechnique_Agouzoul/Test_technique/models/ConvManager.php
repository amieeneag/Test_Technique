<?php


class ConvManager extends Model
{
    public function getMsgs()
    {
        $this->getBdd();
        return $this->getAll('chat', 'Chat');
    }

    public function setMsg($msg)
    {
        $auteur = $_SESSION['pseudo'];
        $date = \date('d-m H:i ');

        $t = $this->getBdd();
        $sql = "INSERT INTO chat (auteur, message, dateMsg)
                 VALUES ('$auteur', '$msg', '$date')";
        $t->query($sql);

    }

    public function getConversation($p1, $p2)
    {

        $req = $this->getBdd()->query('SELECT * FROM conversation WHERE( pseudo1= "' . $p1 . '" AND pseudo2 ="' . $p2 . '")
                                   or(  pseudo1= "' . $p2 . '" AND pseudo2 ="' . $p1 . '" ) ');


        $var = $req->fetchAll();
        $var[] = $p2;
        $var[] = count($var[0]);
        echo json_encode($var);
        die();

    }

    public function setConversation($msg)
    {

        $p1 = $_SESSION['pseudo'];
        $p2 = $_SESSION['nom'];
        $t = $this->getBdd();
        $sql = "INSERT INTO conversation (pseudo1, pseudo2, message)
                 VALUES ('$p1', '$p2', '$msg')";
        $t->query($sql);

    }


}

?>