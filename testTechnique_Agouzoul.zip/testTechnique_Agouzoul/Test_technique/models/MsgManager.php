<?php


class MsgManager extends Model
{
    public function getMsgs()
    {
        $this->getBdd();
        return $this->getAll('chat', 'Chat');
    }

    public function setMsg($msg)
    {
        $auteur = $_SESSION['pseudo'];
        $date = \date('d-m H:i ');

        $t = $this->getBdd();
        $sql = "INSERT INTO chat (auteur, message, dateMsg)
                 VALUES ('$auteur', '$msg', '$date')";
        $t->query($sql);

    }


}

?>