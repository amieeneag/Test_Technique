<?php


class UserManager extends Model
{
    public function getUsers()
    {
        $this->getBdd();
        return $this->getAll('users', 'User');
    }

    public function getUser($pseudo, $password)
    {


        $t = 0;

        $req = $this->getBdd()->prepare('SELECT * FROM users WHERE pseudo= :pseudo and password = :password ');

        $req->execute(array('pseudo' => $pseudo, 'password' => $password));

        $var = $req->fetchAll();

        if ($var != Null) {
            $t = 1;

            $this->getBdd()->query('UPDATE users SET enligne=1 WHERE pseudo="' . $pseudo . '" ');

        } else {

            $req = $this->getBdd()->prepare('SELECT * FROM users WHERE pseudo= :pseudo  ');

            $req->execute(array('pseudo' => $pseudo));

            if ($req->fetchAll() != Null) {
                $t = 0;
            } else {
                $this->setUser($pseudo, $password);
                $t = 1;
            }


        }

        return $t;

    }


    public function deconx($pseudo)
    {

        $pseudo = $pseudo;
        $this->getBdd()->query('UPDATE users SET enligne=0 WHERE pseudo="' . $pseudo . '"  ');


    }

    public function getEnligne($pseudo)
    {

        $req = $this->getBdd()->prepare('SELECT id,pseudo FROM users WHERE pseudo != :pseudo AND enligne=1');

        $req->execute(array('pseudo' => $pseudo));
        $users = $req->fetchAll();
        return $users;


    }

    public function setUser($pseudo, $password)
    {


        $t = $this->getBdd();
        $sql = "INSERT INTO users (pseudo, password, enligne)
                 VALUES ('$pseudo', '$password', '1')";
        $t->query($sql);


    }


}

?>