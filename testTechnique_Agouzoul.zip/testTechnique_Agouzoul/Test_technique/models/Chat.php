<?php

class Chat
{

    private $_id;
    private $_auteur;
    private $_message;
    private $_dateMsg;


//CONSTRUCTEUR
    public function __construct(array $data)
    {

        $this->hydrate($data);
    }

//HYDRATATION
    public function hydrate(array $data)
    {

        foreach ($data as $key => $value) {
            $methode = 'set' . ucfirst($key);
            if (method_exists($this, $methode)) {
                $this->$methode($value);
            }

        }
    }


    public function getId()
    {
        return $this->_id;
    }


    public function setId($id)
    {
        $this->_id = $id;
    }


    public function getAuteur()
    {
        return $this->_auteur;
    }


    public function setAuteur($auteur)
    {
        $this->_auteur = $auteur;
    }


    public function getMessage()
    {
        return $this->_message;
    }

    public function setMessage($message)
    {
        $this->_message = $message;
    }


    public function getDateMsg()
    {
        return $this->_dateMsg;
    }


    public function setDateMsg($date)
    {
        $this->_dateMsg = $date;

    }
}


?>