</body>

<footer>

    <div class="row">
        <hr>
        <div style="font-size: large" class="col-md-3 col-md-offset-4 text-center text-success ">

            Copyright : Agouzoul Ahmed Amine
        </div>
    </div>
</footer>


</html>