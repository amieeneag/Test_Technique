<!DOCTYPE html>


<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="web/css/bootstrap.min.css">
    <link rel="stylesheet" href="web/css/bootstrap-theme.min.css">

    <script src="web/js/jquery-mini.js"></script>
    <script src="web/js/bootstrap.min.js"></script>
    <script src="web/js/connexion.js"></script>

    <title>Application de Chat</title>
</head>
<header>


</header>
<body>