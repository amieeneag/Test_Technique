<?php

require_once('head.php');
?>

<script src="web/js/conversation.js"></script>
<div class="row">

    <div class="col-md-10 col-md-offset-1" style="background-color: whitesmoke;height: 600px">


        <nav class="navbar navbar-inverse ">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="index.php?url=chat">
                        <span style="font-size: 30px;color: cadetblue">  TCHAT</span>
                    </a>
                </div>

                <ul class="nav navbar-nav navbar-right">

                    <li style="font-size: 20px"><a href="#" style="color: white">
                            <span><img style="width: 25px" src="web/image/user.png"></span> <?= $_SESSION['pseudo'] ?>
                        </a></li>
                    <li style="font-size: 17px"><a href="index.php?url=connexion&dec=1"> Deconnexion</a></li>

                </ul>
            </div>
        </nav>


        <div class="row">
            <div class="col-md-6 col-md-offset-1" style="height: 530px;">
                <div id="messages" class="row"
                     style="font-size: 17px;  padding-left: 20px;padding-right: 20px; background-color:white ;height: 440px;overflow:scroll">


                </div>
                <div class="">

                    <input id="message" class="form-control " placeholder="Ecrivez un message" type="text" required>
                    <button id="envoyer" style="margin-top: 5px " class="btn btn-primary">Envoyer</button>

                </div>


            </div>


            <div class="col-md-2 col-md-offset-2" style="height:520px; overflow: scroll">
                <a class="btn  " style="position:fixed;font-size: 17px">Contacts en ligne(<span style="color: red"
                                                                                                id="nb">0</span>) </a>
                <div class="row ">
                    <div class="col-md-12">
                        <br>
                        <hr>

                        <div id="enligne" class="list-group">
                            <img style="margin-left: 60px" width="60px" src="web/image/load.gif">

                        </div>


                    </div>

                    <div>

                    </div>

                </div>

            </div>
        </div>
    </div>
</div>

<?php


require_once('foot.php');
?>

