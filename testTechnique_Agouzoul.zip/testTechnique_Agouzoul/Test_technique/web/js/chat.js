$().ready(function () {


    $('[data-toggle="tooltip"]').tooltip();


    function enligne() {
        $.ajax({
            url: "index.php?url=chat&enligne=true", success: function (data) {


                x = JSON.parse(data);
                c = x.length;
                $('#enligne').html("");
                $('#nb').html("");
                $('#nb').html(c);

                for (i = 0; i < c; i++) {

                    $('#enligne').append("<a  style='font-size: 16px' data-toggle='tooltip' data-placement='top'  title='Cliquer pour chatter' href='index.php?url=conversation&nom=" + x[i].pseudo + "' class=' list-group-item list-group-item-action'>" +
                        "<img style='width: 10px;margin-right: 25px' src='web/image/cercle.jpg'>" + x[i].pseudo + "</a>");


                }
                $('[data-toggle="tooltip"]').tooltip();


            }
        });

    }

    setInterval(enligne, 1000);


    function messages() {
        $.ajax({
            url: "index.php?url=message", success: function (data) {


                x = JSON.parse(data);

                c = x.length;


                $('#messages').html("");

                for (i = 0; i < c; i++) {

                    $('#messages').append('  <div style=";margin-top: 10px; color:white;margin-left: 15px;font-size: 16px"> ' +
                        '<span style="font-size: large">  <span style="text-decoration: underline">' +
                        x[i].dateMsg + '  ' + x[i].auteur + '</span> : </span> ' + x[i]['message'] + ' </div>');

                }
                $('#messages').scrollTop(100);


            }
        });


    }


    setInterval(messages, 1000);

    $('#envoyer').on('click', function (e) {
        e.preventDefault();


        var msg = $('#message').val();


        $.ajax({
            url: 'index.php?url=message&rajouter=true',
            type: 'post',
            data: 'message=' + msg,

            success: function (req) {

                $('#message').val("");
            }


        });


    });


});


