$().ready(function () {

    $('#form1').on('submit', function (e) {
        e.preventDefault();


        var password = $('#pwd').val();

        var pseudo = $('#pseudo').val();


        if (!pseudo.match(/^[a-z0-9]+$/i)) {

            $('#erreur').removeClass('hidden');
            $('#erreur').html('<div class="alert-warning " style="font-size:17px ;"> Entrez un pseudo contenat juste des ' +
                'lettres et des nombres </div> ');
            return false;
        }


        $.ajax({
            url: 'index.php?url=connexion',
            type: 'post',
            data: 'pseudo=' + pseudo + '&password=' + password,

            success: function (data) {
                if (data == 0) {
                    $('#erreur').removeClass('hidden');
                    $('#erreur').html('<div class="alert-danger " style="font-size:17px ;"> Entrez un pseudo ou un password correcte </div> ');

                } else {
                    $(location).attr("href", 'index.php?url=chat');

                }

            }


        });


    });
    $('#dec').on('click', function (e) {
        e.preventDefault();

        $(location).attr("href", 'index.php?url=deconnexion');


    });


});


