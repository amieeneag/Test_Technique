<?php


class ControllerAcceuil
{


    public function __construct($url)
    {
        if (isset($url) && count($url) > 1) {

            throw new Exception ('Page Introuvable 2');

        } else {
            $this->accueil();
        }

    }

    public function accueil()
    {

        require_once('views/viewAccueil.php');
    }


}

?>