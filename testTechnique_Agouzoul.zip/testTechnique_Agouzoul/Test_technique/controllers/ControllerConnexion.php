<?php
session_start();

class ControllerConnexion
{

    private $_userManager;


    public function __construct($url)
    {


        if (isset($url) && count($url) > 1) {

            throw new Exception ('Page introuvable ');

        } else {
            if (isset($_GET['dec']) && $_GET['dec'] == '1') {

                $this->deconnexion();
            } else {

                $this->connexion();

            }

        }

    }


    public function connexion()
    {


        $pseudo = (htmlentities(addslashes(htmlspecialchars($_POST['pseudo']))));

        $password = (htmlentities(addslashes(htmlspecialchars($_POST['password']))));


        $this->_userManager = new UserManager();
        $t = $this->_userManager->getUser($pseudo, $password);
        if ($t == 1) {
            $_SESSION['pseudo'] = $pseudo;
        }
        echo json_encode($t);

    }

    public function deconnexion()
    {


        $pseudo = $_SESSION['pseudo'];


        $this->_userManager = new UserManager();
        $this->_userManager->deconx($pseudo);

        session_unset();
        session_destroy();
        ?>
        <script> window.location.href = 'index.php';</script>

        <?php

    }


}

?>