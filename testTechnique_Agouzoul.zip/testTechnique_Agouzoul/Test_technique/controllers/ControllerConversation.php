<?php

session_start();
if (!isset($_SESSION['pseudo'])) {
    ?>
    <script>
        window.location.href = 'index.php';</script>

    <?php
}

class ControllerConversation
{

    private $_convManager;


    public function __construct($url)
    {


        if (isset($url) && count($url) > 1) {

            throw new Exception ('Page introuvable ');

        } else {


            if (isset($_GET['nom'])) {
                $_SESSION['nom'] = $_GET['nom'];
                $this->conversation();
            } elseif (isset($_GET['donne']) && $_GET['donne'] == "true") {
                $this->getConversation();

            } elseif (isset($_GET['rajouter']) && $_GET['rajouter'] == "true") {

                $this->setConversation();

            } else {
                throw new Exception ('Page introuvable ');
            }
        }


    }

    public function conversation()
    {


        require_once('views/viewConversation.php');

    }

    public function getConversation()
    {
        $p1 = $_SESSION['pseudo'];
        $p2 = $_SESSION['nom'];
        $this->_convManager = new ConvManager();
        $t = $this->_convManager->getConversation($p1, $p2);

        echo json_encode($t);

    }

    public function setConversation()
    {
        $msg = (htmlspecialchars($_POST['message']));

        $this->_convManager = new ConvManager();
        $t = $this->_convManager->setConversation($msg);
        return 1;

    }


}

?>