-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Mer 13 Juin 2018 à 15:20
-- Version du serveur: 5.5.60-0ubuntu0.14.04.1
-- Version de PHP: 5.5.9-1ubuntu4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `tchat`
--

-- --------------------------------------------------------

--
-- Structure de la table `chat`
--

CREATE TABLE IF NOT EXISTS `chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `auteur` varchar(10) NOT NULL,
  `message` text NOT NULL,
  `dateMsg` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

--
-- Contenu de la table `chat`
--

INSERT INTO `chat` (`id`, `auteur`, `message`, `dateMsg`) VALUES
(16, 'amineag', 'bonjour tout le monde ', '06-13 10-00'),
(17, 'amineag', 'ou est vous', '13-06 10-01'),
(20, 'amineag', 'olla amigo', '13-06 10:14 '),
(22, 'amineag', 'bienvenu yahya', '13-06 10:39 '),
(26, 'yahya', 'oooh les amis cava', '13-06 11:28 '),
(28, 'amineag', 'vous etes ou les gars !', '13-06 12:22 '),
(29, 'amineag', 'je vous attends tjrs', '13-06 12:51 '),
(30, 'yahya', 'je suis pres de toi', '13-06 15:05 '),
(31, 'imade', 'les gas oléé', '13-06 15:14 '),
(32, 'amineag', 'oooh', '13-06 15:14 ');

-- --------------------------------------------------------

--
-- Structure de la table `conversation`
--

CREATE TABLE IF NOT EXISTS `conversation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo1` varchar(10) NOT NULL,
  `pseudo2` varchar(10) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Contenu de la table `conversation`
--

INSERT INTO `conversation` (`id`, `pseudo1`, `pseudo2`, `message`) VALUES
(1, 'amineag', 'yahya', 'bonjour yahya cava'),
(2, 'yahya', 'amineag', 'ca va hamd et toi'),
(3, 'amineag', 'yahya', 'ca va aussi merci'),
(4, 'yahya', 'amineag', 'keske tu rac ?'),
(5, 'amineag', 'yahya', 'rien de spe et toi'),
(6, 'yahya', 'amineag', 'moi aussi'),
(7, 'amineag', 'yahya', 'tres bien tu es ou'),
(24, 'imade', 'amineag', 'ca fait un plaisir amine'),
(25, 'amineag', 'imade', 'le plaisir est a moi'),
(26, 'amineag', 'imade', ' cava toi ?');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `enligne` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `pseudo` (`pseudo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `users`
--

INSERT INTO `users` (`id`, `pseudo`, `password`, `enligne`) VALUES
(1, 'amineag', 'amine', 0),
(2, 'yassine', 'yassine', 0),
(3, 'imade', 'imade', 0),
(4, 'yahya', 'yahya', 0),
(10, 'youtouD', 'youoy', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
