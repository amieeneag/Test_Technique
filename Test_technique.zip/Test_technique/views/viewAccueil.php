<?php
require_once('head.php');
?>


<div class="row" style="padding-top: 80px;">

    <div style="border: solid lightgrey" class=" col-md-3 col-md-offset-4">


        <br>

        <form id="form1" action="#">
            <img class="img-responsive " src="web/image/tchat.jpeg"><br>
            <div id="erreur" class="hidden">
                <div class="alert-danger " style="font-size:17px ;"></div>
                <br>
            </div>
            <div class="form-group">
                <label for="pseudo">Pseudo:</label>
                <input type="text" class="form-control" autocomplete="off" id="pseudo" required>
            </div>
            <div class="form-group">
                <label for="pwd">Password:</label>
                <input type="password" class="form-control" id="pwd" required>
            </div>

            <button type="submit" id="submit" class="btn btn-primary">Connexion</button>
        </form>
        <br>
    </div>

</div>
<?php

require_once('foot.php');
?>

