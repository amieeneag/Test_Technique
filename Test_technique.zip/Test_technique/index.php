<?php

require_once ('controllers/Router.php');

$route=new Router();
$route->routeReq();

?>