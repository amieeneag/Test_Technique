$().ready(function () {


    $('[data-toggle="tooltip"]').tooltip();


    function enligne() {
        $.ajax({
            url: "index.php?url=chat&enligne=true", success: function (data) {


                x = JSON.parse(data);
                c = x.length;
                $('#enligne').html("");
                $('#nb').html("");
                $('#nb').html(c);

                for (i = 0; i < c; i++) {

                    $('#enligne').append("<a  style='font-size: 16px' data-toggle='tooltip' data-placement='top'  title='Cliquer pour chatter' href='index.php?url=conversation&nom=" + x[i].pseudo + "' class=' list-group-item list-group-item-action'>" +
                        "<img style='width: 10px;margin-right: 25px' src='web/image/cercle.jpg'>" + x[i].pseudo + "</a>");


                }
                $('[data-toggle="tooltip"]').tooltip();


            }
        });

    }

    setInterval(enligne, 1000);


    function messages() {

        $.ajax({
            url: 'index.php?url=conversation&donne=true', success: function (data) {


                x = JSON.parse(data);
                nb = (x.length);
                c = nb - 2;
                var nom = x[nb - 2]
                $('#messages').html("");
                $('#messages').append('<h3> ' + nom + ' </h3><hr>')

                for (var i = 0; i < nb - 2; i++) {
                    if (x[i].pseudo1 == nom) {
                        $('#messages').append('<div style="font-size: 20px" class="row text-warning text-left" >' + x[i].message + '</div> ');
                    } else {
                        $('#messages').append('<div style="font-size: 20px" class="row  text-primary text-right" >' + x[i].message + '</div> ');
                    }


                }
                $('#messages').scrollTop(2000);


            }
        });


    }


    setInterval(messages, 1000);

    $('#envoyer').on('click', function (e) {
        e.preventDefault();


        var msg = $('#message').val();


        $.ajax({
            url: 'index.php?url=conversation&rajouter=true',
            type: 'post',
            data: 'message=' + msg,

            success: function (req) {

                $('#message').val(" ");
            }


        });


    });


});


