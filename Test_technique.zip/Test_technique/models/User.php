<?php


class User
{

    private $_id;
    private $_pseudo;
    private $_password;
    private $_enligne;


    //CONSTRUCTEUR
    public function __construct(array $data)
    {

        $this->hydrate($data);
    }

    //HYDRATATION
    public function hydrate(array $data)
    {

        foreach ($data as $key => $value) {
            $methode = 'set' . ucfirst($key);
            if (method_exists($this, $methode)) {
                $this->$methode($value);
            }

        }


    }

    //GETTER et SETTERS
    public function getId()
    {
        return $this->_id;
    }


    public function setId($id)
    {
        $this->_id = $id;
    }


    public function getPseudo()
    {
        return $this->_pseudo;
    }


    public function setPseudo($pseudo)
    {
        $this->_pseudo = $pseudo;
    }


    public function getPassword()
    {
        return $this->_password;
    }


    public function setPassword($password)
    {
        $this->_pwd = $password;
    }


    public function getEnligne()
    {
        return $this->_enligne;
    }


    public function setEnligne($enligne = 1)
    {
        $this->_enligne = $enligne;
    }


}