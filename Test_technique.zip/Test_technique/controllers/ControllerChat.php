<?php

session_start();

class ControllerChat
{

    private $_userManager;


    public function __construct($url)
    {


        if (isset($url) && count($url) > 1) {

            throw new Exception ('Page introuvable ');

        } else {


            if (isset($_SESSION['pseudo'])) {

                if (isset($_GET['enligne']) && ($_GET['enligne'] = "true")) {
                    $this->enligne();
                } else {
                    $this->chat();
                }

            } else {
                ?>
                <script>
                    window.location.href = 'index.php';</script>

                <?php
            }
        }

    }


    public function chat()
    {

        require_once('views/viewChat.php');

    }

    public function enligne()
    {
        $pseudo = $_SESSION['pseudo'];
        $this->_userManager = new UserManager();
        $t = $this->_userManager->getEnligne($pseudo);
        echo json_encode($t);

    }


}

?>