<?php

session_start();

class ControllerMessage
{


    private $_msgManager;


    public function __construct($url)
    {


        if (isset($url) && count($url) > 1) {

            throw new Exception ('Page introuvable ');

        } else {


            if (isset($_SESSION['pseudo'])) {

                if (isset($_GET['rajouter']) && ($_GET['rajouter'] = "true")) {
                    $this->setMessage();
                } else {
                    $this->getMsg();
                }

            } else {
                ?>
                <script>
                    window.location.href = 'index.php';</script>

                <?php
            }
        }

    }


    public function getMsg()
    {

        $this->_msgManager = new MsgManager();
        $t = $this->_msgManager->getMsgs();

        $x = count($t);
        $var = [];

        for ($i = 0; $i < $x; $i++) {

            $var[$i]['id'] = $t[$i]->getId();
            $var[$i]['auteur'] = $t[$i]->getAuteur();
            $var[$i]['message'] = $t[$i]->getMessage();
            $var[$i]['dateMsg'] = $t[$i]->getDateMsg();
        }
        echo json_encode($var);


    }

    public function setMessage()
    {


        $msg = (htmlspecialchars($_POST['message']));
        $this->_msgManager = new MsgManager();
        $t = $this->_msgManager->setMsg($msg);
        return 'oui';

    }


}

?>